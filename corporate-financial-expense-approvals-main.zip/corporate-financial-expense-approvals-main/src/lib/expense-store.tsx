import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type Role = "Employee" | "Manager" | "FinanceAdmin";
export type ReportStatus = "Draft" | "Submitted" | "ManagerApproved" | "FinanceApproved" | "Rejected";
export type Category = "Travel" | "Meals" | "Software" | "OfficeSupplies" | "ClientEntertainment";
export type AuditAction = "Submitted" | "ApprovedByManager" | "ApprovedByFinance" | "Rejected";

export const CATEGORIES: Category[] = ["Travel", "Meals", "Software", "OfficeSupplies", "ClientEntertainment"];
export const CATEGORY_LABEL: Record<Category, string> = {
  Travel: "Travel",
  Meals: "Meals",
  Software: "Software",
  OfficeSupplies: "Office Supplies",
  ClientEntertainment: "Client Entertainment",
};

export interface User {
  id: string;
  fullName: string;
  email: string;
  role: Role;
  department: string;
  managerId: string | null;
  createdAt: string;
}
export interface ExpenseItem {
  id: string;
  reportId: string;
  category: Category;
  amount: number;
  date: string;
  merchant: string;
  receiptUrl?: string | undefined;
}
export interface ExpenseReport {
  id: string;
  reportNumber: string;
  userId: string;
  title: string;
  description: string;
  totalAmount: number;
  status: ReportStatus;
  submittedAt: string | null;
  createdAt: string;
}
export interface AuditLog {
  id: string;
  reportId: string;
  actorId: string;
  action: AuditAction;
  comments?: string | undefined;
  timestamp: string;
}

interface DB {
  users: User[];
  reports: ExpenseReport[];
  items: ExpenseItem[];
  logs: AuditLog[];
}

export const DEPARTMENT_BUDGETS: Record<string, number> = {
  Engineering: 12000,
  Sales: 9000,
  Finance: 4000,
};

function seed(): DB {
  const users: User[] = [
    { id: "u-sarah", fullName: "Sarah Smith", email: "sarah.smith@corp.io", role: "Manager", department: "Engineering", managerId: null, createdAt: "2025-01-10" },
    { id: "u-alex", fullName: "Alex Rivera", email: "alex.rivera@corp.io", role: "FinanceAdmin", department: "Finance", managerId: null, createdAt: "2025-01-12" },
    { id: "u-john", fullName: "John Doe", email: "john.doe@corp.io", role: "Employee", department: "Engineering", managerId: "u-sarah", createdAt: "2025-02-01" },
    { id: "u-priya", fullName: "Priya Patel", email: "priya.patel@corp.io", role: "Employee", department: "Sales", managerId: "u-sarah", createdAt: "2025-03-14" },
  ];
  const items: ExpenseItem[] = [
    { id: "i1", reportId: "r1", category: "Travel", amount: 642.3, date: "2026-08-04", merchant: "Delta Airlines", receiptUrl: "delta-ticket.pdf" },
    { id: "i2", reportId: "r1", category: "Meals", amount: 86.4, date: "2026-08-05", merchant: "Blue Bottle Café" },
    { id: "i3", reportId: "r1", category: "Travel", amount: 389, date: "2026-08-05", merchant: "Hilton Midtown", receiptUrl: "hilton-folio.pdf" },
    { id: "i4", reportId: "r2", category: "Software", amount: 299, date: "2026-09-02", merchant: "JetBrains", receiptUrl: "jetbrains-invoice.pdf" },
    { id: "i5", reportId: "r2", category: "OfficeSupplies", amount: 145.75, date: "2026-09-03", merchant: "Staples" },
    { id: "i6", reportId: "r3", category: "ClientEntertainment", amount: 512.2, date: "2026-09-18", merchant: "Nobu Downtown", receiptUrl: "nobu-receipt.jpg" },
    { id: "i7", reportId: "r3", category: "Travel", amount: 74.5, date: "2026-09-18", merchant: "Uber" },
    { id: "i8", reportId: "r4", category: "Meals", amount: 48.9, date: "2026-10-01", merchant: "Sweetgreen" },
  ];
  const sum = (r: string) => items.filter((i) => i.reportId === r).reduce((a, b) => a + b.amount, 0);
  const reports: ExpenseReport[] = [
    { id: "r1", reportNumber: "EXP-2026-001", userId: "u-john", title: "NYC client summit", description: "Flights, hotel and meals for the August summit.", totalAmount: sum("r1"), status: "FinanceApproved", submittedAt: "2026-08-07", createdAt: "2026-08-06" },
    { id: "r2", reportNumber: "EXP-2026-002", userId: "u-john", title: "Dev tooling & desk setup", description: "IDE licence and ergonomic supplies.", totalAmount: sum("r2"), status: "Submitted", submittedAt: "2026-09-04", createdAt: "2026-09-04" },
    { id: "r3", reportNumber: "EXP-2026-003", userId: "u-priya", title: "Q3 prospect dinner", description: "Dinner with Acme Corp procurement team.", totalAmount: sum("r3"), status: "ManagerApproved", submittedAt: "2026-09-19", createdAt: "2026-09-19" },
    { id: "r4", reportNumber: "EXP-2026-004", userId: "u-john", title: "Team lunch", description: "Sprint retro lunch.", totalAmount: sum("r4"), status: "Draft", submittedAt: null, createdAt: "2026-10-01" },
  ];
  const logs: AuditLog[] = [
    { id: "l1", reportId: "r1", actorId: "u-john", action: "Submitted", timestamp: "2026-08-07T09:12:00Z" },
    { id: "l2", reportId: "r1", actorId: "u-sarah", action: "ApprovedByManager", comments: "Summit pre-approved.", timestamp: "2026-08-08T14:30:00Z" },
    { id: "l3", reportId: "r1", actorId: "u-alex", action: "ApprovedByFinance", comments: "Reimbursed in Aug payroll.", timestamp: "2026-08-10T11:05:00Z" },
    { id: "l4", reportId: "r2", actorId: "u-john", action: "Submitted", timestamp: "2026-09-04T16:20:00Z" },
    { id: "l5", reportId: "r3", actorId: "u-priya", action: "Submitted", timestamp: "2026-09-19T08:45:00Z" },
    { id: "l6", reportId: "r3", actorId: "u-sarah", action: "ApprovedByManager", comments: "Strategic account.", timestamp: "2026-09-20T10:00:00Z" },
  ];
  return { users, reports, items, logs };
}

const PERSONAS: Record<Role, string> = { Employee: "u-john", Manager: "u-sarah", FinanceAdmin: "u-alex" };
const KEY = "ledgerline-db-v1";

export interface NewItemInput {
  category: Category;
  amount: number;
  date: string;
  merchant: string;
  receiptUrl?: string | undefined;
}

interface Ctx {
  db: DB;
  role: Role;
  setRole: (r: Role) => void;
  currentUser: User;
  userById: (id: string) => User | undefined;
  itemsFor: (reportId: string) => ExpenseItem[];
  logsFor: (reportId: string) => AuditLog[];
  visibleReports: ExpenseReport[];
  queue: ExpenseReport[];
  createReport: (input: { title: string; description: string; items: NewItemInput[]; submit: boolean }) => void;
  submitDraft: (reportId: string) => void;
  transition: (reportId: string, decision: "approve" | "reject", comments?: string) => void;
  resetDemo: () => void;
}

const StoreCtx = createContext<Ctx | null>(null);

const uid = () => `${Date.now().toString(36)}${Math.floor(Math.random() * 1e6).toString(36)}`;

export function ExpenseStoreProvider({ children }: { children: ReactNode }) {
  const [db, setDb] = useState<DB>(() => seed());
  const [role, setRole] = useState<Role>("Employee");
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setDb(JSON.parse(raw));
      const r = localStorage.getItem(KEY + "-role") as Role | null;
      if (r) setRole(r);
    } catch {}
    setLoaded(true);
  }, []);
  useEffect(() => {
    if (loaded) {
      localStorage.setItem(KEY, JSON.stringify(db));
      localStorage.setItem(KEY + "-role", role);
    }
  }, [db, role, loaded]);

  const value = useMemo<Ctx>(() => {
    const currentUser = db.users.find((u) => u.id === PERSONAS[role])!;
    const userById = (id: string) => db.users.find((u) => u.id === id);
    const team = db.users.filter((u) => u.managerId === currentUser.id).map((u) => u.id);
    let visibleReports: ExpenseReport[];
    let queue: ExpenseReport[];
    if (role === "Employee") {
      visibleReports = db.reports.filter((r) => r.userId === currentUser.id);
      queue = [];
    } else if (role === "Manager") {
      visibleReports = db.reports.filter((r) => team.includes(r.userId) && r.status !== "Draft");
      queue = visibleReports.filter((r) => r.status === "Submitted");
    } else {
      visibleReports = db.reports.filter((r) => ["ManagerApproved", "FinanceApproved", "Rejected"].includes(r.status));
      queue = db.reports.filter((r) => r.status === "ManagerApproved");
    }
    const nextNumber = () => {
      const max = db.reports.reduce((m, r) => Math.max(m, parseInt(r.reportNumber.split("-")[2] ?? "0", 10)), 0);
      return `EXP-2026-${String(max + 1).padStart(3, "0")}`;
    };
    return {
      db,
      role,
      setRole,
      currentUser,
      userById,
      itemsFor: (id) => db.items.filter((i) => i.reportId === id),
      logsFor: (id) => db.logs.filter((l) => l.reportId === id).sort((a, b) => a.timestamp.localeCompare(b.timestamp)),
      visibleReports: [...visibleReports].sort((a, b) => b.createdAt.localeCompare(a.createdAt)),
      queue,
      createReport: ({ title, description, items, submit }) => {
        const id = uid();
        const now = new Date().toISOString();
        const newItems = items.map((i) => ({ ...i, id: uid(), reportId: id }));
        const report: ExpenseReport = {
          id,
          reportNumber: nextNumber(),
          userId: currentUser.id,
          title,
          description,
          totalAmount: newItems.reduce((a, b) => a + b.amount, 0),
          status: submit ? "Submitted" : "Draft",
          submittedAt: submit ? now : null,
          createdAt: now.slice(0, 10),
        };
        setDb((d) => ({
          ...d,
          reports: [...d.reports, report],
          items: [...d.items, ...newItems],
          logs: submit ? [...d.logs, { id: uid(), reportId: id, actorId: currentUser.id, action: "Submitted", timestamp: now }] : d.logs,
        }));
      },
      submitDraft: (reportId) => {
        const now = new Date().toISOString();
        setDb((d) => ({
          ...d,
          reports: d.reports.map((r) => (r.id === reportId ? { ...r, status: "Submitted", submittedAt: now } : r)),
          logs: [...d.logs, { id: uid(), reportId, actorId: currentUser.id, action: "Submitted", timestamp: now }],
        }));
      },
      transition: (reportId, decision, comments) => {
        const report = db.reports.find((r) => r.id === reportId);
        if (!report) return;
        let next: ReportStatus | null = null;
        let action: AuditAction | null = null;
        if (decision === "reject") {
          if (!comments?.trim()) throw new Error("A rejection reason is required.");
          if ((role === "Manager" && report.status === "Submitted") || (role === "FinanceAdmin" && report.status === "ManagerApproved")) {
            next = "Rejected";
            action = "Rejected";
          }
        } else if (role === "Manager" && report.status === "Submitted") {
          next = "ManagerApproved";
          action = "ApprovedByManager";
        } else if (role === "FinanceAdmin" && report.status === "ManagerApproved") {
          next = "FinanceApproved";
          action = "ApprovedByFinance";
        }
        if (!next || !action) throw new Error("You are not allowed to perform this transition.");
        const a = action;
        const n = next;
        setDb((d) => ({
          ...d,
          reports: d.reports.map((r) => (r.id === reportId ? { ...r, status: n } : r)),
          logs: [...d.logs, { id: uid(), reportId, actorId: currentUser.id, action: a, comments: comments?.trim() || undefined, timestamp: new Date().toISOString() }],
        }));
      },
      resetDemo: () => setDb(seed()),
    };
  }, [db, role]);

  return <StoreCtx.Provider value={value}>{children}</StoreCtx.Provider>;
}

export function useExpenses() {
  const c = useContext(StoreCtx);
  if (!c) throw new Error("useExpenses must be inside ExpenseStoreProvider");
  return c;
}

export const money = (n: number) => n.toLocaleString("en-US", { style: "currency", currency: "USD" });
