import { Link } from "@tanstack/react-router";
import { BarChart3, ClipboardCheck, Receipt, RotateCcw } from "lucide-react";
import { useExpenses, type Role } from "@/lib/expense-store";

const ROLES: { role: Role; label: string }[] = [
  { role: "Employee", label: "Employee · John Doe" },
  { role: "Manager", label: "Manager · Sarah Smith" },
  { role: "FinanceAdmin", label: "Finance · Alex Rivera" },
];

export function AppHeader() {
  const { role, setRole, queue, resetDemo } = useExpenses();
  const nav = "flex items-center gap-2 px-3 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground";
  return (
    <header className="border-b bg-card">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-4 px-6 py-3">
        <Link to="/" className="flex items-center gap-2">
          <span className="grid h-8 w-8 place-items-center rounded-sm bg-primary font-mono text-sm font-bold text-primary-foreground">L</span>
          <span className="font-semibold tracking-tight">Ledgerline</span>
        </Link>
        <nav className="flex flex-1 items-center gap-1">
          <Link to="/my-expenses" className={nav} activeProps={{ className: "text-foreground nav-active" }}>
            <Receipt className="h-4 w-4" /> My Expenses
          </Link>
          {role !== "Employee" && (
            <Link to="/approvals" className={nav} activeProps={{ className: "text-foreground nav-active" }}>
              <ClipboardCheck className="h-4 w-4" /> Approvals
              {queue.length > 0 && <span className="rounded-sm bg-accent px-1.5 font-mono text-[11px] text-accent-foreground">{queue.length}</span>}
            </Link>
          )}
          {role !== "Employee" && (
            <Link to="/analytics" className={nav} activeProps={{ className: "text-foreground nav-active" }}>
              <BarChart3 className="h-4 w-4" /> Analytics
            </Link>
          )}
        </nav>
        <div className="flex items-center gap-2">
          <span className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">Viewing as</span>
          <div className="flex rounded-sm border bg-muted p-0.5">
            {ROLES.map((r) => (
              <button
                key={r.role}
                onClick={() => setRole(r.role)}
                className={`rounded-sm px-3 py-1.5 text-xs transition-colors ${role === r.role ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
              >
                {r.label}
              </button>
            ))}
          </div>
          <button onClick={resetDemo} title="Reset demo data" className="p-2 text-muted-foreground hover:text-foreground">
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>
      </div>
    </header>
  );
}
