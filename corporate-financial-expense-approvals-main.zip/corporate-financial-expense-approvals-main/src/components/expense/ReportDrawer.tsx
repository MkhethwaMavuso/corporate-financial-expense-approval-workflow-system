import { useState } from "react";
import { Check, FileText, X } from "lucide-react";
import { toast } from "sonner";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { CATEGORY_LABEL, money, useExpenses, type ExpenseReport } from "@/lib/expense-store";
import { StatusBadge } from "./StatusBadge";

const ACTION_LABEL = { Submitted: "Submitted", ApprovedByManager: "Approved by manager", ApprovedByFinance: "Approved by finance", Rejected: "Rejected" };

export function ReportDrawer({ report, onClose }: { report: ExpenseReport | null; onClose: () => void }) {
  const { itemsFor, logsFor, userById, role, transition, currentUser, submitDraft } = useExpenses();
  const [comment, setComment] = useState("");
  const [rejecting, setRejecting] = useState(false);

  const close = () => { setComment(""); setRejecting(false); onClose(); };
  const items = report ? itemsFor(report.id) : [];
  const logs = report ? logsFor(report.id) : [];
  const owner = report ? userById(report.userId) : undefined;
  const byCat = items.reduce<Record<string, number>>((a, i) => ({ ...a, [i.category]: (a[i.category] || 0) + i.amount }), {});
  const canAct = report && ((role === "Manager" && report.status === "Submitted") || (role === "FinanceAdmin" && report.status === "ManagerApproved"));

  const act = (d: "approve" | "reject") => {
    if (!report) return;
    try {
      transition(report.id, d, comment);
      toast.success(d === "approve" ? "Report approved." : "Report rejected.");
      close();
    } catch (e) {
      toast.error((e as Error).message);
    }
  };

  return (
    <Sheet open={!!report} onOpenChange={(o) => !o && close()}>
      <SheetContent className="w-full overflow-y-auto sm:max-w-xl">
        {report && (
          <>
            <SheetHeader>
              <div className="font-mono text-xs text-muted-foreground">{report.reportNumber}</div>
              <SheetTitle className="text-xl">{report.title}</SheetTitle>
              <div className="flex items-center gap-3"><StatusBadge status={report.status} /><span className="text-sm text-muted-foreground">{owner?.fullName} · {owner?.department}</span></div>
            </SheetHeader>
            <div className="grid gap-6 px-4 pb-8">
              {report.description && <p className="text-sm text-muted-foreground">{report.description}</p>}
              <section>
                <h3 className="section-label">Line items</h3>
                <div className="divide-y rounded-sm border">
                  {items.map((i) => (
                    <div key={i.id} className="flex items-center justify-between gap-3 p-3 text-sm">
                      <div>
                        <div className="font-medium">{i.merchant}</div>
                        <div className="text-xs text-muted-foreground">{CATEGORY_LABEL[i.category]} · {i.date}</div>
                        {i.receiptUrl && (
                          <div className="mt-1.5 inline-flex items-center gap-1.5 rounded-sm border bg-muted px-2 py-1 font-mono text-[11px]">
                            <FileText className="h-3 w-3" /> {i.receiptUrl}
                          </div>
                        )}
                      </div>
                      <div className="font-mono">{money(i.amount)}</div>
                    </div>
                  ))}
                  <div className="flex justify-between bg-muted/50 p-3 font-medium"><span>Total</span><span className="font-mono">{money(report.totalAmount)}</span></div>
                </div>
              </section>
              <section>
                <h3 className="section-label">Category breakdown</h3>
                <div className="grid gap-2">
                  {Object.entries(byCat).map(([c, v]) => (
                    <div key={c} className="text-sm">
                      <div className="flex justify-between"><span>{CATEGORY_LABEL[c as keyof typeof CATEGORY_LABEL]}</span><span className="font-mono text-muted-foreground">{Math.round((v / report.totalAmount) * 100)}%</span></div>
                      <div className="mt-1 h-1.5 bg-muted"><div className="h-full bg-primary" style={{ width: `${(v / report.totalAmount) * 100}%` }} /></div>
                    </div>
                  ))}
                </div>
              </section>
              <section>
                <h3 className="section-label">Audit history</h3>
                {logs.length === 0 ? <p className="text-sm text-muted-foreground">No activity yet — still a draft.</p> : (
                  <ol className="relative ml-2 border-l">
                    {logs.map((l) => (
                      <li key={l.id} className="mb-4 ml-4">
                        <span className={`absolute -left-1.5 mt-1 h-3 w-3 rounded-full border-2 border-card ${l.action === "Rejected" ? "bg-destructive" : "bg-primary"}`} />
                        <div className="text-sm font-medium">{ACTION_LABEL[l.action]} <span className="font-normal text-muted-foreground">by {userById(l.actorId)?.fullName}</span></div>
                        <div className="font-mono text-[11px] text-muted-foreground">{new Date(l.timestamp).toLocaleString()}</div>
                        {l.comments && <div className="mt-1 text-sm italic text-muted-foreground">“{l.comments}”</div>}
                      </li>
                    ))}
                  </ol>
                )}
              </section>
              {report.status === "Draft" && report.userId === currentUser.id && (
                <Button onClick={() => { submitDraft(report.id); toast.success("Submitted for review."); close(); }}>Submit for review</Button>
              )}
              {canAct && (
                <section className="grid gap-3 rounded-sm border bg-muted/40 p-4">
                  <h3 className="section-label mb-0">Decision</h3>
                  <Textarea value={comment} onChange={(e) => setComment(e.target.value)} rows={2} placeholder={rejecting ? "Reason for rejection (required)" : "Comment (optional)"} />
                  <div className="flex gap-2">
                    <Button className="flex-1" onClick={() => act("approve")}><Check className="h-4 w-4" /> Approve</Button>
                    <Button className="flex-1" variant="destructive" onClick={() => { if (!comment.trim()) { setRejecting(true); toast.error("Add a reason before rejecting."); return; } act("reject"); }}><X className="h-4 w-4" /> Reject</Button>
                  </div>
                </section>
              )}
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
