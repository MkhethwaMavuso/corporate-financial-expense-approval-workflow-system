import { useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { CATEGORIES, CATEGORY_LABEL, money, useExpenses, type Category } from "@/lib/expense-store";

interface Row { category: Category; amount: string; date: string; merchant: string; receiptUrl: string }
const emptyRow = (): Row => ({ category: "Travel", amount: "", date: "", merchant: "", receiptUrl: "" });

export function NewReportDialog() {
  const { createReport } = useExpenses();
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [rows, setRows] = useState<Row[]>([emptyRow()]);

  const total = rows.reduce((a, r) => a + (parseFloat(r.amount) || 0), 0);
  const update = (i: number, patch: Partial<Row>) => setRows((rs) => rs.map((r, j) => (j === i ? { ...r, ...patch } : r)));

  const save = (submit: boolean) => {
    if (!title.trim()) { toast.error("Add a report title."); return; }
    const valid = rows.every((r) => r.merchant.trim() && r.date && parseFloat(r.amount) > 0);
    if (!valid) { toast.error("Every line item needs a merchant, date and positive amount."); return; }
    createReport({
      title: title.trim(),
      description: description.trim(),
      submit,
      items: rows.map((r) => ({ category: r.category, amount: parseFloat(r.amount), date: r.date, merchant: r.merchant.trim(), receiptUrl: r.receiptUrl.trim() || undefined })),
    });
    toast.success(submit ? "Report submitted for manager review." : "Draft saved.");
    setOpen(false);
    setTitle("");
    setDescription("");
    setRows([emptyRow()]);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button><Plus className="h-4 w-4" /> New Expense Report</Button>
      </DialogTrigger>
      <DialogContent className="max-h-[90vh] max-w-3xl overflow-y-auto">
        <DialogHeader><DialogTitle>New expense report</DialogTitle></DialogHeader>
        <div className="grid gap-4">
          <div className="grid gap-1.5">
            <Label>Title</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Berlin partner visit" />
          </div>
          <div className="grid gap-1.5">
            <Label>Description</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} />
          </div>
          <div className="grid gap-2">
            <div className="flex items-center justify-between">
              <Label>Line items</Label>
              <Button variant="outline" size="sm" onClick={() => setRows((r) => [...r, emptyRow()])}><Plus className="h-3.5 w-3.5" /> Add item</Button>
            </div>
            {rows.map((r, i) => (
              <div key={i} className="grid grid-cols-12 gap-2 rounded-sm border bg-muted/40 p-2">
                <select className="field col-span-3" value={r.category} onChange={(e) => update(i, { category: e.target.value as Category })}>
                  {CATEGORIES.map((c) => <option key={c} value={c}>{CATEGORY_LABEL[c]}</option>)}
                </select>
                <Input className="col-span-3" placeholder="Merchant" value={r.merchant} onChange={(e) => update(i, { merchant: e.target.value })} />
                <Input className="col-span-2" type="date" value={r.date} onChange={(e) => update(i, { date: e.target.value })} />
                <Input className="col-span-2 font-mono" type="number" min="0" step="0.01" placeholder="0.00" value={r.amount} onChange={(e) => update(i, { amount: e.target.value })} />
                <Button variant="ghost" size="icon" className="col-span-2 justify-self-end" disabled={rows.length === 1} onClick={() => setRows((rs) => rs.filter((_, j) => j !== i))}>
                  <Trash2 className="h-4 w-4" />
                </Button>
                <Input className="col-span-12 text-xs" placeholder="Receipt file name or URL (optional)" value={r.receiptUrl} onChange={(e) => update(i, { receiptUrl: e.target.value })} />
              </div>
            ))}
          </div>
          <div className="flex items-center justify-between border-t pt-4">
            <div>
              <div className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">Total</div>
              <div className="font-mono text-2xl">{money(total)}</div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => save(false)}>Save draft</Button>
              <Button onClick={() => save(true)}>Submit for review</Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
