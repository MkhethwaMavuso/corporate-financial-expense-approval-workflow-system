import type { ReportStatus } from "@/lib/expense-store";
import { cn } from "@/lib/utils";

const MAP: Record<ReportStatus, { label: string; cls: string }> = {
  Draft: { label: "Draft", cls: "status-draft" },
  Submitted: { label: "Submitted", cls: "status-pending" },
  ManagerApproved: { label: "Manager Approved", cls: "status-progress" },
  FinanceApproved: { label: "Finance Approved", cls: "status-approved" },
  Rejected: { label: "Rejected", cls: "status-rejected" },
};

export function StatusBadge({ status }: { status: ReportStatus }) {
  const s = MAP[status];
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-sm px-2 py-0.5 font-mono text-[11px] uppercase tracking-wider", s.cls)}>
      <span className="h-1.5 w-1.5 rounded-full bg-current" />
      {s.label}
    </span>
  );
}
