import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronRight, Inbox } from "lucide-react";
import { money, useExpenses, type ExpenseReport } from "@/lib/expense-store";
import { StatusBadge } from "@/components/expense/StatusBadge";
import { ReportDrawer } from "@/components/expense/ReportDrawer";

export const Route = createFileRoute("/approvals")({
  head: () => ({
    meta: [
      { title: "Approval Queue — Ledgerline" },
      { name: "description", content: "Review, approve or reject pending expense reports." },
      { property: "og:title", content: "Approval Queue — Ledgerline" },
      { property: "og:description", content: "Review, approve or reject pending expense reports." },
    ],
  }),
  component: Approvals,
});

function Approvals() {
  const { role, queue, visibleReports, userById, itemsFor } = useExpenses();
  const [open, setOpen] = useState<ExpenseReport | null>(null);

  if (role === "Employee") {
    return (
      <div className="mx-auto max-w-xl px-6 py-24 text-center">
        <h1 className="text-2xl font-semibold">Approvals are for managers and finance</h1>
        <p className="mt-2 text-muted-foreground">Switch your role in the toolbar, or head to <Link to="/my-expenses" className="underline">My Expenses</Link>.</p>
      </div>
    );
  }
  const history = visibleReports.filter((r) => !queue.includes(r));

  return (
    <div className="mx-auto max-w-7xl px-6 py-10">
      <div className="section-label">{role === "Manager" ? "Manager review · team submissions" : "Finance review · manager-approved reports"}</div>
      <h1 className="text-3xl font-semibold tracking-tight">Approval queue</h1>
      <div className="mt-8 grid gap-3">
        {queue.length === 0 && (
          <div className="flex flex-col items-center gap-2 rounded-sm border border-dashed py-14 text-muted-foreground"><Inbox className="h-6 w-6" />Inbox zero — nothing awaiting your review.</div>
        )}
        {queue.map((r) => {
          const u = userById(r.userId);
          return (
            <button key={r.id} onClick={() => setOpen(r)} className="queue-row">
              <div className="grid h-10 w-10 place-items-center rounded-sm bg-muted font-mono text-sm">{u?.fullName.split(" ").map((p) => p[0]).join("")}</div>
              <div className="flex-1 text-left">
                <div className="font-medium">{r.title}</div>
                <div className="text-xs text-muted-foreground"><span className="font-mono">{r.reportNumber}</span> · {u?.fullName} · {u?.department} · {itemsFor(r.id).length} items</div>
              </div>
              <StatusBadge status={r.status} />
              <div className="w-28 text-right font-mono">{money(r.totalAmount)}</div>
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </button>
          );
        })}
      </div>
      <h2 className="section-label mt-12">Recently processed</h2>
      <div className="overflow-x-auto rounded-sm border bg-card">
        <table className="ledger-table">
          <thead><tr><th>Report</th><th>Employee</th><th>Title</th><th>Status</th><th className="text-right">Amount</th></tr></thead>
          <tbody>
            {history.length === 0 && <tr><td colSpan={5} className="py-8 text-center text-muted-foreground">Nothing processed yet.</td></tr>}
            {history.map((r) => (
              <tr key={r.id} onClick={() => setOpen(r)}>
                <td className="font-mono text-xs">{r.reportNumber}</td>
                <td>{userById(r.userId)?.fullName}</td>
                <td>{r.title}</td>
                <td><StatusBadge status={r.status} /></td>
                <td className="text-right font-mono">{money(r.totalAmount)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <ReportDrawer report={open} onClose={() => setOpen(null)} />
    </div>
  );
}
