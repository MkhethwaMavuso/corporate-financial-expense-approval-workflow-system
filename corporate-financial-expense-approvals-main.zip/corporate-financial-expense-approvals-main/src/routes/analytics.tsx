import { createFileRoute } from "@tanstack/react-router";
import { CATEGORIES, CATEGORY_LABEL, DEPARTMENT_BUDGETS, money, useExpenses } from "@/lib/expense-store";

export const Route = createFileRoute("/analytics")({
  head: () => ({
    meta: [
      { title: "Financial Analytics — Ledgerline" },
      { name: "description", content: "Monthly spend, pending totals, category breakdown and department budget utilization." },
      { property: "og:title", content: "Financial Analytics — Ledgerline" },
      { property: "og:description", content: "Monthly spend, pending totals, category breakdown and department budget utilization." },
    ],
  }),
  component: Analytics,
});

function Analytics() {
  const { db, role, userById } = useExpenses();
  if (role === "Employee") {
    return <div className="mx-auto max-w-xl px-6 py-24 text-center"><h1 className="text-2xl font-semibold">Analytics is restricted to managers and finance</h1><p className="mt-2 text-muted-foreground">Switch your role in the toolbar to view it.</p></div>;
  }
  const active = db.reports.filter((r) => r.status !== "Draft" && r.status !== "Rejected");
  const approvedIds = new Set(db.reports.filter((r) => r.status === "FinanceApproved").map((r) => r.id));
  const activeIds = new Set(active.map((r) => r.id));
  const pending = db.reports.filter((r) => r.status === "Submitted" || r.status === "ManagerApproved").reduce((a, r) => a + r.totalAmount, 0);
  const approved = db.reports.filter((r) => approvedIds.has(r.id)).reduce((a, r) => a + r.totalAmount, 0);

  const monthly: Record<string, number> = {};
  db.items.filter((i) => activeIds.has(i.reportId)).forEach((i) => { const m = i.date.slice(0, 7); monthly[m] = (monthly[m] || 0) + i.amount; });
  const months = Object.entries(monthly).sort(([a], [b]) => a.localeCompare(b));
  const maxMonth = Math.max(1, ...months.map(([, v]) => v));

  const byCat = CATEGORIES.map((c) => ({ c, v: db.items.filter((i) => activeIds.has(i.reportId) && i.category === c).reduce((a, i) => a + i.amount, 0) }));
  const catTotal = byCat.reduce((a, b) => a + b.v, 0) || 1;

  const depts = Object.entries(DEPARTMENT_BUDGETS).map(([d, budget]) => {
    const spent = active.filter((r) => userById(r.userId)?.department === d).reduce((a, r) => a + r.totalAmount, 0);
    return { d, budget, spent, pct: (spent / budget) * 100 };
  });

  return (
    <div className="mx-auto max-w-7xl px-6 py-10">
      <div className="section-label">Finance & analytics</div>
      <h1 className="text-3xl font-semibold tracking-tight">Spend overview</h1>
      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        <div className="stat-card stat-approved"><div className="section-label mb-2">Reimbursed (finance approved)</div><div className="font-mono text-3xl">{money(approved)}</div></div>
        <div className="stat-card stat-pending"><div className="section-label mb-2">Pending approval</div><div className="font-mono text-3xl">{money(pending)}</div></div>
        <div className="stat-card stat-draft"><div className="section-label mb-2">Committed spend</div><div className="font-mono text-3xl">{money(approved + pending)}</div></div>
      </div>
      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <section className="rounded-sm border bg-card p-6">
          <h2 className="section-label">Spend by category</h2>
          <div className="grid gap-4">
            {byCat.map(({ c, v }) => (
              <div key={c}>
                <div className="flex justify-between text-sm"><span>{CATEGORY_LABEL[c]}</span><span className="font-mono text-muted-foreground">{money(v)} · {Math.round((v / catTotal) * 100)}%</span></div>
                <div className="mt-1.5 h-2.5 bg-muted"><div className="bar-fill h-full" style={{ width: `${(v / catTotal) * 100}%` }} /></div>
              </div>
            ))}
          </div>
        </section>
        <section className="rounded-sm border bg-card p-6">
          <h2 className="section-label">Monthly spend</h2>
          <div className="flex h-56 items-end gap-4">
            {months.map(([m, v]) => (
              <div key={m} className="flex flex-1 flex-col items-center gap-2">
                <span className="font-mono text-[11px] text-muted-foreground">{money(v)}</span>
                <div className="bar-fill w-full" style={{ height: `${(v / maxMonth) * 160}px` }} />
                <span className="font-mono text-xs">{m}</span>
              </div>
            ))}
          </div>
        </section>
      </div>
      <section className="mt-6 overflow-x-auto rounded-sm border bg-card">
        <table className="ledger-table">
          <thead><tr><th>Department</th><th className="text-right">Budget</th><th className="text-right">Spent</th><th className="w-1/3">Utilization</th></tr></thead>
          <tbody>
            {depts.map((d) => (
              <tr key={d.d}>
                <td className="font-medium">{d.d}</td>
                <td className="text-right font-mono">{money(d.budget)}</td>
                <td className="text-right font-mono">{money(d.spent)}</td>
                <td>
                  <div className="flex items-center gap-3">
                    <div className="h-2 flex-1 bg-muted"><div className={d.pct > 90 ? "h-full bg-destructive" : "bar-fill h-full"} style={{ width: `${Math.min(100, d.pct)}%` }} /></div>
                    <span className="w-12 text-right font-mono text-xs">{d.pct.toFixed(1)}%</span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </div>
  );
}
