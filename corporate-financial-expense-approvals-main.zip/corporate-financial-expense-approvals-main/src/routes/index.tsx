import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Ledgerline — Expense & Approval Workflow" },
      { name: "description", content: "Corporate expense reporting with manager and finance approval workflows." },
      { property: "og:title", content: "Ledgerline — Expense & Approval Workflow" },
      { property: "og:description", content: "Corporate expense reporting with manager and finance approval workflows." },
    ],
  }),
  beforeLoad: () => {
    throw redirect({ to: "/my-expenses" });
  },
});
