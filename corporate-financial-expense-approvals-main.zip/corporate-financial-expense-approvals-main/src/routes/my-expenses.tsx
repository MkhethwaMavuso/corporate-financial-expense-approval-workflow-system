import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { money, useExpenses, type ExpenseReport } from "@/lib/expense-store";
import { StatusBadge } from "@/components/expense/StatusBadge";
import { NewReportDialog } from "@/components/expense/NewReportDialog";
import { ReportDrawer } from "@/components/expense/ReportDrawer";

export const Route = createFileRoute("/my-expenses")({
  head: () => ({
    meta: [
      { title: "My Expenses — Ledgerline" },
      { name: "description", content: "Track your expense reports, reimbursements and pending approvals." },
      { property: "og:title", content: "My Expenses — Ledgerline" },
      { property: "og:description", content: "Track your expense reports, reimbursements and pending approvals." },
    ],
  }),
  component: MyExpenses,
});

function MyExpenses() {
  const { db, currentUser } = useExpenses();
  const [open, setOpen] = useState<ExpenseReport | null>(null);
  const mine = db.reports.filter((r) => r.userId === currentUser.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const reimbursed = mine.filter((r) => r.status === "FinanceApproved").reduce((a, r) => a + r.totalAmount, 0);
  const pending = mine.filter((r) => r.status === "Submitted" || r.status === "ManagerApproved").reduce((a, r) => a + r.totalAmount, 0);
  const drafts = mine.filter((r) => r.status === "Draft").length;

  return (
    <div className="mx-auto max-w-7xl px-6 py-10">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="section-label">Employee portal</div>
          <h1 className="text-3xl font-semibold tracking-tight">Welcome back, {currentUser.fullName.split(" ")[0]}</h1>
        </div>
        <NewReportDialog />
      </div>
      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        <Stat label="Total reimbursed" value={money(reimbursed)} tone="approved" />
        <Stat label="Pending approvals" value={money(pending)} tone="pending" />
        <Stat label="Draft reports" value={String(drafts)} tone="draft" />
      </div>
      <div className="mt-8 overflow-x-auto rounded-sm border bg-card">
        <table className="ledger-table">
          <thead><tr><th>Report</th><th>Title</th><th>Created</th><th>Status</th><th className="text-right">Amount</th></tr></thead>
          <tbody>
            {mine.length === 0 && <tr><td colSpan={5} className="py-10 text-center text-muted-foreground">No reports yet.</td></tr>}
            {mine.map((r) => (
              <tr key={r.id} onClick={() => setOpen(r)}>
                <td className="font-mono text-xs">{r.reportNumber}</td>
                <td className="font-medium">{r.title}</td>
                <td className="text-muted-foreground">{r.createdAt}</td>
                <td><StatusBadge status={r.status} /></td>
                <td className="text-right font-mono">{money(r.totalAmount)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <ReportDrawer report={open} onClose={() => setOpen(null)} />
    </div>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone: string }) {
  return (
    <div className={`stat-card stat-${tone}`}>
      <div className="section-label mb-2">{label}</div>
      <div className="font-mono text-3xl">{value}</div>
    </div>
  );
}
